﻿namespace DI_Demo.DI
{
    public class SingleTonClass : ISingleTonMessages
    {
        private string _value = "Default_SingleTon";
        public string GetValue()
        {
            return _value;
        }
        public void SetValue(string value)
        {
            _value = value;
        }
    }
}
