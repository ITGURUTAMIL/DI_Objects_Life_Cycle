﻿namespace DI_Demo.DI
{
    public interface ISingleTonMessages
    {
        public string GetValue();
        public void SetValue(string _value);
    }
}
