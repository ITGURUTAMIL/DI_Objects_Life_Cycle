﻿namespace DI_Demo.DI
{
    public interface IScopedMessages
    {
        public string GetValue();
        public void SetValue(string _value);
    }
}
