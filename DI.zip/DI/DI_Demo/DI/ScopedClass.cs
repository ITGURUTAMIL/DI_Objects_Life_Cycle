﻿ 

namespace DI_Demo.DI
{
    public class ScopedClass : IScopedMessages
    {
       private string _value = "Default_Scoped";
       public  string GetValue()
        {
            return _value;
        }

        public void SetValue(string value)
        {
            _value = value;
        }
    }
}
