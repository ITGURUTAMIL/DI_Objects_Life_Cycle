﻿namespace DI_Demo.DI
{
    public class TransientClass : ITransientMessages
    {
        private string _value = "Default_Transient";
        public string GetValue()
        {
            return _value;
        }
        public void SetValue(string value)
        {
            _value = value;
        }
    }
}
