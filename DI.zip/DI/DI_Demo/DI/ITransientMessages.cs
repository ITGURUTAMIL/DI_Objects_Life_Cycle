﻿namespace DI_Demo.DI
{
    public interface ITransientMessages
    {
        public string GetValue();
        public void SetValue(string _value);
    }
}
