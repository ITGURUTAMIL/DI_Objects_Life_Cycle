﻿using Microsoft.AspNetCore.Mvc;

using DI_Demo.DI;
using Microsoft.AspNetCore.Http;

namespace DI_Demo.Controllers
{
    public class ScopedController : Controller
    {
        IScopedMessages _obj;

        public ScopedController(IScopedMessages obj )
        { _obj = obj; }
        public IActionResult Index()
        {
            ViewBag.Message = _obj.GetValue();
            return View();
        }

        [HttpPost]
        public IActionResult SetValue(IFormCollection collection)
        {
            _obj.SetValue(collection["SetMessage"]);
            ViewBag.Message = _obj.GetValue();

            return View("Index");
        }

    }
}
